# Big Data Analytics - Project 1: 2,000 social-media records -> marketing decision
# Google Colab: ye poori file ek cell me paste karke run karo. Output: social_media_posts.csv, results.json, dashboard.html
import numpy as np, pandas as pd, json, time

# ---------- STEP 1-2: DATASET (agar apka lecturer ka CSV hai to is block ki jagah pd.read_csv('file.csv') lagao) ----------
rng = np.random.default_rng(42)
N = 2000
types = rng.choice(["Reel","Carousel","Image","Story"], N, p=[.35,.25,.28,.12])
cats = rng.choice(["Lawn","Winter Collection","Bridal","Casual Wear","Sale"], N, p=[.28,.2,.15,.22,.15])
hour = rng.choice(range(8,24), N)
dates = pd.to_datetime("2025-01-01") + pd.to_timedelta(rng.integers(0,365,N), unit="D")
followers = (50000 + (dates - pd.Timestamp("2025-01-01")).days*40 + rng.normal(0,500,N)).astype(int)
tmul = pd.Series(types).map({"Reel":1.8,"Carousel":1.3,"Image":1.0,"Story":0.6}).values
cmul = pd.Series(cats).map({"Lawn":1.2,"Winter Collection":1.0,"Bridal":1.5,"Casual Wear":0.9,"Sale":1.1}).values
hmul = np.where((hour>=19)&(hour<=22),1.5,np.where(hour<11,0.7,1.0))
reach = (followers*0.25*tmul*hmul*rng.lognormal(0,.35,N)).astype(int)
er = 0.035*tmul*cmul*np.where((hour>=19)&(hour<=22),1.25,1)*rng.lognormal(0,.25,N)
inter = (reach*er).astype(int)
df = pd.DataFrame({"post_id":range(1,N+1),"date":dates,"post_type":types,"category":cats,"hour":hour,
  "followers":followers,"hashtags":rng.integers(0,25,N),"caption_len":rng.integers(20,400,N),
  "has_discount":rng.choice([0,1],N,p=[.7,.3]),"reach":reach,
  "likes":(inter*.8).astype(int),"comments":(inter*.07).astype(int),
  "shares":(inter*.05).astype(int),"saves":(inter*.08).astype(int)})
# gandagi inject karo (real data jaisa)
df.loc[rng.choice(N,40,replace=False),"caption_len"]=np.nan
df.loc[rng.choice(N,25,replace=False),"reach"]=np.nan
df = pd.concat([df, df.sample(15, random_state=1)]).reset_index(drop=True)
df.to_csv("data/social_media_posts.csv", index=False)

# ---------- STEP 3: INSPECT ----------
df = pd.read_csv("data/social_media_posts.csv", parse_dates=["date"])
print(df.shape); print(df.isna().sum()[df.isna().sum()>0]); print("duplicates:", df.duplicated().sum())

# ---------- STEP 4: CLEAN ----------
df = df.drop_duplicates()
df["caption_len"] = df["caption_len"].fillna(df["caption_len"].median())
df = df.dropna(subset=["reach"]); df = df[df["reach"]>0]

# ---------- STEP 5: FEATURES ----------
df["interactions"] = df[["likes","comments","shares","saves"]].sum(axis=1)
df["eng_rate"] = df["interactions"]/df["reach"]*100
df["weekday"] = df["date"].dt.day_name()
df["slot"] = pd.cut(df["hour"],[7,10,14,18,22,23],labels=["Morning 8-10","Midday 11-14","Evening 15-18","Prime 19-22","Late 23"])

# ---------- STEP 6-7: EDA ----------
def grp(c): return df.groupby(c,observed=True)["eng_rate"].agg(["mean","count"]).round(2).sort_values("mean",ascending=False)
by_type, by_cat, by_slot = grp("post_type"), grp("category"), grp("slot")
by_day = grp("weekday"); by_disc = grp("has_discount")
corr = df[["eng_rate","hashtags","caption_len","has_discount","hour","followers"]].corr()["eng_rate"].drop("eng_rate").round(3)
combo = df.groupby(["post_type","slot"],observed=True)["eng_rate"].agg(["mean","count"])
combo = combo[combo["count"]>=15].sort_values("mean",ascending=False).round(2)
best = combo.index[0]
rec = (f"Publish more {best[0]}s in the {best[1]} slot, focused on {by_cat.index[0]} content. "
       f"Avg engagement {combo.iloc[0]['mean']}% vs overall {df['eng_rate'].mean():.2f}%.")
print(rec)

# ---------- STEP 8: SCALE TEST (Pandas kab slow hota hai?) ----------
scale = []
for mult in [1, 100, 1000]:
    big = pd.concat([df]*mult, ignore_index=True) if mult<=1000 else df
    t=time.time(); big.groupby(["post_type","slot"],observed=True)["eng_rate"].mean(); dt=time.time()-t
    scale.append({"rows":len(big),"seconds":round(dt,3),"mb":round(big.memory_usage(deep=True).sum()/1e6,1)})
    del big
print(scale)

# ---------- STEP 9-10: EXPORT + DASHBOARD ----------
to = lambda s:[{"k":str(i),"v":float(r["mean"]),"n":int(r["count"])} for i,r in s.iterrows()]
R = {"rows":len(df),"avg":round(df.eng_rate.mean(),2),"by_type":to(by_type),"by_cat":to(by_cat),"by_slot":to(by_slot),
     "by_day":to(by_day),"corr":corr.to_dict(),"rec":rec,"scale":scale,
     "top":[{"k":f"{a} · {b}","v":float(r["mean"]),"n":int(r["count"])} for (a,b),r in combo.head(5).iterrows()]}
json.dump(R, open("results/results.json","w"), indent=1)

html = """<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Project 1 – Social Media Marketing Decision</title><style>
:root{--bg:#faf8f5;--card:#fff;--tx:#1d1b19;--mu:#6b655e;--ac:#c2410c;--bar:#e7e0d8;--bd:#e7e0d8}
@media (prefers-color-scheme:dark){:root:not([data-theme=light]){--bg:#161412;--card:#201d1a;--tx:#f3eee8;--mu:#a59d93;--ac:#fb923c;--bar:#3a342e;--bd:#3a342e}}
body{margin:0;background:var(--bg);color:var(--tx);font:16px/1.5 system-ui,sans-serif;padding:20px;max-width:960px;margin:auto}
h1{font-size:1.6rem;margin:.2em 0}.sub{color:var(--mu);margin-bottom:20px}
.rec{background:var(--ac);color:#fff;padding:18px;border-radius:14px;font-size:1.1rem;margin-bottom:20px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:14px}
.card{background:var(--card);border:1px solid var(--bd);border-radius:14px;padding:16px}
h2{font-size:1rem;margin:0 0 10px}.row{display:grid;grid-template-columns:130px 1fr 52px;gap:8px;align-items:center;font-size:.85rem;margin:6px 0}
.b{height:14px;background:var(--bar);border-radius:7px;overflow:hidden}.b i{display:block;height:100%;background:var(--ac)}
table{width:100%;border-collapse:collapse;font-size:.85rem}td,th{text-align:left;padding:5px;border-bottom:1px solid var(--bd)}
.lim{color:var(--mu);font-size:.9rem;margin-top:8px}</style></head><body>
<h1>Which content should the brand publish next?</h1><div class="sub" id="sub"></div>
<div class="rec" id="rec"></div><div class="grid" id="g"></div>
<div class="card" style="margin-top:14px"><h2>Pandas ko scale karo: kya badalta hai?</h2><table id="sc"></table>
<div class="lim">Limitation: Pandas poora data RAM me load karta hai. 2K rows pe instant hai, magar jab data GBs me jaye (multiple platforms, comments text, daily logs) tab Spark/Dask jaisa distributed tool justify hota hai.</div></div>
<script>const R=__DATA__;
document.getElementById('sub').textContent=R.rows+' cleaned posts · average engagement rate '+R.avg+'%';
document.getElementById('rec').textContent='Recommendation: '+R.rec;
function chart(t,a){const m=Math.max(...a.map(x=>x.v));return '<div class="card"><h2>'+t+'</h2>'+a.map(x=>'<div class="row"><span>'+x.k+'</span><div class="b"><i style="width:'+(x.v/m*100)+'%"></i></div><span>'+x.v+'%</span></div>').join('')+'</div>'}
document.getElementById('g').innerHTML=chart('By post type',R.by_type)+chart('By category',R.by_cat)+chart('By time slot',R.by_slot)+chart('By weekday',R.by_day)+chart('Top 5 type + time combos',R.top);
document.getElementById('sc').innerHTML='<tr><th>Rows</th><th>Groupby time (s)</th><th>Memory (MB)</th></tr>'+R.scale.map(s=>'<tr><td>'+s.rows.toLocaleString()+'</td><td>'+s.seconds+'</td><td>'+s.mb+'</td></tr>').join('')
</script></body></html>""".replace("__DATA__", json.dumps(R))
open("docs/dashboard.html","w").write(html)
